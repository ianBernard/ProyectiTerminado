import app from './app'

app.listen(8080)
console.log('server on port 8080')