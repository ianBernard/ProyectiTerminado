import * as React from 'react';
import { StatusBar } from 'expo-status-bar';
import { StyleSheet, SafeAreaView, FlatList, Text, View, Image, TextInput, TouchableOpacity, onPress, ActivityIndicator, ScrollView, TouchableHighlight } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { useEffect, useState } from 'react'
import RecetaCard from './components/RecetaCard'
import axios from 'axios';

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


function IniciarScreen({ navigation }) {
  return (
    <View style={styles.container}>
      <View
        style={{
          backgroundColor: "white",
          width: "100%",
          height: "100%",
          flex: 1,
          position: 'absolute'
        }}
      />
      <View
        style={{
          backgroundColor: "#DA4343",
          width: "100%",
          height: 300,
          position: 'absolute'
        }}
      />
      <Text style={styles.titulo}>SlimFit</Text>
      <Image source={require('./assets/App/logo.jpg')} style={styles.logo} />
      <TextInput
        style={{
          top: 400,
          width: 300,
          alignSelf: "center",
          textAlign: "center",
          position: 'absolute',
          borderWidth: 3,
          height: 50,
          fontWeight: "bold",
          borderColor: '#DA4343',
          borderRadius:10
        }}
        placeholder="Username"
        placeholderTextColor="#DA4343"
        keyboardType="default"
      />
      <TextInput
        secureTextEntry={true}
        style={{
          top: 500,
          width: 300,
          textAlign: "center",
          position: 'absolute',
          borderWidth: 3,
          height: 50,
          fontWeight: "bold",
          borderColor: "#DA4343",
          borderRadius: 10
        }}
        placeholder="Password"
        placeholderTextColor="#DA4343"
        keyboardType="default"
      />
      <TouchableOpacity
        style={styles.button1}
        onPress={() => navigation.navigate('Posts')}
      >
        <Text style={{
          fontSize: 16,
          color: "white",
          top: "25%"
        }}>Iniciar Sesion</Text>
      </TouchableOpacity>
      <TouchableOpacity
        style={styles.button2}
        onPress={onPress}
      >
        <Text style={{
          fontSize: 16,
          color: "white",
          top: "25%"
        }}>Registrarse</Text>
      </TouchableOpacity>
      <StatusBar style="auto" />
    </View>
  );
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function PostsScreen({ navigation }) {
var [data, setData] = useState([]);


  const fetchData = async () => {
    const resp = await fetch("https://192.168.1.14:8080/recetas");
    const info = await resp.json();
    setData(info);
    
  };

  const styles = StyleSheet.create({
    container: {
      flex: 1,
      marginTop: StatusBar.currentHeight || 0,
    },
    item: {
      backgroundColor: '#b42222',
      padding: 80,
      marginVertical: 40,
      marginHorizontal: 0,
      height: "10%",

    },

      BarradeAbajo: {
        bottom: -14
      },
      card: {
        marginLeft: "auto",
        marginRight: "auto",
        borderColor: "#731a1a",
        borderWidth: 5,
        borderRadius: 10,
        backgroundColor: "#DA4343",
        width: "100%",
        height: 500,
    
      },
      fondo:{
        backgroundColor: "white",
        width: "100%",
        height: "100%",
        flex: 1,
        position: 'absolute'
      },
      receta:{
        color: "#ffffff",
        fontSize: 32,
        fontWeight: "bold",
        textAlign: "center",
        width: 285,
        position: "absolute"
      },
      ImagenPerfil:{
        height: 50,
        width: 50,
        position: "absolute",
        alignSelf: "center",
        top: 5
      },
      Upvote:{
        height: 50,
        width: 50,
        position: "absolute",
        alignSelf: "center",
        top: 60
    },
    
      textoUpvote:{
        alignSelf: "center",
        top: "28%",
        position: "absolute",
        color: "#ffffff",
        fontSize: 24
      },
      Downvote:{
        height: 50,
        width: 50,
        position: "absolute",
        alignSelf: "center",
        top: 190
      },
      CaldoDePollo: {
        height: 190,
        width: 315,
        top: 50,
        position: "absolute",
        left: 0,
        borderRadius: 5
      },
      OtrosDatos:{
        alignSelf: "center",
        top: "50%",
        position: "absolute",
        color: "#ffffff",
        fontSize: 24
      },
      TextoDownvotes:{
        alignSelf: "left",
        top: "60%",
        position: "absolute",
        color: "#ffffff",
        fontSize: 24
      },
      textoDescripcion:{
    
        alignSelf: "left",
        top: "70%",
        position: "absolute",
        color: "#ffffff",
        fontSize: 24
      },
    
      textoVisitas:{
    
        alignSelf: "left",
        top: "87%",
        position: "absolute",
        color: "#ffffff",
        fontSize: 24
      },
      barritadeabajo:{
          height: 65,
          position: "relative",
          top: "164%",
          backgroundColor: "#ff0000"
        
      },
      cardAAA:{width: "93%",
      alignSelf: "center"},
      estonosequees:{
        backgroundColor: "#ffffff",
        width: "100%",
        height: 25
      },
      estotampocosequees:{
        backgroundColor: "#b42222",
        width: 60,
        alignSelf: "flex-end",
        height: "100%"
      }
    }
  );

  const Item = ({ NombreReceta, upvotes, downvotes, visitas, descripcios }) => (
    // <View style={styles.item}>
    // <Text style={styles.texto}>{NombreReceta}</Text>
    // </View>    
    <View
        style={styles.card}>
        <ScrollView>  
           <View name="Card" style={styles.targeta}>
              <View style={styles.targeta} > 
                <Text style={styles.item}>{NombreReceta}</Text>
             </View>
             
           </View> 
           </ScrollView>
    </View> 
  );

  const renderItem = ({ item }) => (
        <View>
          
      <ScrollView>

          <View name="Card" style={
            styles.cardAAA
          }>
            <View style={styles.estonosequees} />
            <View style={styles.card} >
              <Text style={styles.receta}>{item.NombreReceta}</Text>                
              <View style={styles.estotampocosequees}>
                <Image style={styles.ImagenPerfil} source={require("./assets/App/DefaultProfile.png")} />
                <TouchableOpacity><Image style={styles.Upvote} source={require("./assets/App/Upvote.png")} /></TouchableOpacity>
                <Text style={styles.textoUpvote}> {item.upvotes}</Text>
                <TouchableOpacity><Image style={styles.Downvote} source={require("./assets/App/Downvote.png")} /></TouchableOpacity>
              </View>
              <Image source={require("./assets/App/CaldoDePollo.jpg")} style={styles.CaldoDePollo} 
              />
              <Text style={styles.OtrosDatos}>OTROS DATOS:</Text>
                  <Text style={styles.TextoDownvotes}>  - downvotes: {item.downvotes}</Text>
                <Text style={styles.textoDescripcion}>  - descripcion: {item.descripcios}</Text>
                <Text style={styles.textoVisitas}>  - visitas: {item.visitas}</Text>
            </View>
          </View>
          
          <View style={styles.barritadeabajo} />
        </ScrollView>
        
        </View>

      
  );


  
  useEffect(() => {
    // fetchData();
    fetch("http://192.168.1.14:8080/recetas")
    .then(response => response.json())
    .then(data =>{setData(data)} )
  }, []);

  return (
    <SafeAreaView style={styles.container}>
    <FlatList
      data={data}
      renderItem={renderItem}
      keyExtractor={item => item.idReceta}
    />
  </SafeAreaView>
  
  );
  };








  function popo ({ navigation }) {
  let [receta, setReceta] = useState(null)
  let [upvotes, setUpvote] = useState(null)
  let [downvotes, setDownvotes] = useState(null)
  let [visitas, setvisitas] = useState(null)
  let [descripcios, setdescripcios] = useState(null)

  useEffect(() => {
    fetch("http://192.168.1.14:8080/recetas")
    .then(response => response.json())
    .then(data =>{setReceta(data[0].NombreReceta)
                   setUpvote(data[0].upvotes)
                   setDownvotes(data[0].downvotes)
                   setvisitas(data[0].visitas)
                   setdescripcios(data[0].descripcios)


                  } )
    // .then(data => setUpvote(data[0].upvotes))
    // .then(data => setDownvotes(data[0].downvotes))
    
  },[])
  return (
    <View style={styles.container}>
      <View
        style={styles.fondo}>
        <ScrollView>

          <View name="Card" style={
            styles.cardAAA
          }>
            <View style={styles.estonosequees} />
            <View style={styles.card} >
              <Text style={styles.receta}>{receta}</Text>                
              <View style={styles.estotampocosequees}>
                <Image style={styles.ImagenPerfil} source={require("./assets/App/DefaultProfile.png")} />
                <TouchableOpacity><Image style={styles.Upvote} source={require("./assets/App/Upvote.png")} /></TouchableOpacity>
                <Text style={styles.textoUpvote}>{upvotes}</Text>
                <TouchableOpacity><Image style={styles.Downvote} source={require("./assets/App/Downvote.png")} /></TouchableOpacity>
              </View>
              <Image source={require("./assets/App/CaldoDePollo.jpg")} style={styles.CaldoDePollo} 
              />
              <Text style={styles.OtrosDatos}>OTROS DATOS:</Text>
                  <Text style={styles.TextoDownvotes}>  - downvotes: {downvotes}</Text>
                <Text style={styles.textoDescripcion}>  - descripcion: {descripcios}</Text>
                <Text style={styles.textoVisitas}>  - visitas: {visitas}</Text>
            </View>
          </View>
          
          <View style={styles.barritadeabajo} />
        </ScrollView>
      </View>


      <View style={styles.bottomBar}>
        <TouchableOpacity style={styles.BarradeAbajo} onPress={() => navigation.navigate('Posts')}><Image source={require('./assets/App/IconoHome.png')} style={styles.iconobarra}></Image></TouchableOpacity>
        <TouchableOpacity style={styles.BarradeAbajo}><Image source={require('./assets/App/IconoBuscar.png')} style={styles.iconobarra}></Image></TouchableOpacity>
        <TouchableOpacity style={styles.BarradeAbajo} onPress={() => navigation.navigate('Crear')}><Image source={require('./assets/App/IconoCrear.png')} style={styles.iconobarra}></Image></TouchableOpacity>
        <TouchableOpacity style={styles.BarradeAbajo}><Image source={require('./assets/App/IconoUsuario.png')} style={styles.iconobarra}></Image></TouchableOpacity>
        <TouchableOpacity style={styles.BarradeAbajo}><Image source={require('./assets/App/IconoNotificacion.png')} style={styles.iconobarra}></Image></TouchableOpacity>
      </View>
    </View>
  );
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function CrearScreen({ navigation }) {
  return (
    <View style={styles.container}>
      <View
        style={{
          backgroundColor: "white",
          width: "89%",
          height: "100%",
          flex: 1,
          position: 'absolute'
        }}>
        <Text
          style={{
            position: 'absolute',
            alignSelf: 'center',
            top: 60,
            fontSize: 25,
            fontWeight: "bold",
            color: "#000000",
            textAlign: "center"
          }} > Elige el tipo de publicación</Text>
        <TouchableOpacity onPress={() => navigation.navigate('CrearReceta')} style={{
          height: 300,
          width: 300,
          alignSelf: 'center',
          top: 150,
          position: "absolute",
          borderRadius:5

        }}>
          <Image source={require("./assets/App/CrearReceta.jpg")} style={{
            height: 300,
            width: 300,
            borderRadius:5
          }} />
          <Text style={{
            color: "white",
            alignSelf: "center",
            position: "absolute",
            fontSize: 50,
            fontWeight: "bold",
            top: 115
          }}>Receta</Text>
        </TouchableOpacity>

        <TouchableOpacity onPress={() => navigation.navigate('CrearRutina')} style={{
          height: 300,
          width: 300,
          alignSelf: 'center',
          top: 470,
          position: "absolute",
          borderRadius:5
        }}>
          <Image source={require("./assets/App/CrearRutina.jpg")} style={{
            height: 300,
            width: 300,
            borderRadius:5
          }} />
          <Text style={{
            color: "white",
            alignSelf: "center",
            position: "absolute",
            fontSize: 50,
            fontWeight: "bold",
            top: 115
          }}>Rutina</Text>
        </TouchableOpacity>
      </View>
      <View style={styles.bottomBar}>
        <TouchableOpacity style={styles.BarradeAbajo} onPress={() => navigation.navigate('Posts')}><Image source={require('./assets/App/IconoHome.png')} style={styles.iconobarra}></Image></TouchableOpacity>
        <TouchableOpacity style={styles.BarradeAbajo}><Image source={require('./assets/App/IconoBuscar.png')} style={styles.iconobarra}></Image></TouchableOpacity>
        <TouchableOpacity style={styles.BarradeAbajo} onPress={() => navigation.navigate('Crear')}><Image source={require('./assets/App/IconoCrear.png')} style={styles.iconobarra}></Image></TouchableOpacity>
        <TouchableOpacity style={styles.BarradeAbajo}><Image source={require('./assets/App/IconoUsuario.png')} style={styles.iconobarra}></Image></TouchableOpacity>
        <TouchableOpacity style={styles.BarradeAbajo}><Image source={require('./assets/App/IconoNotificacion.png')} style={styles.iconobarra}></Image></TouchableOpacity>
      </View>
    </View>
  )
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function CrearRutina({ navigation }) {

  return (
    <View style={styles.container}>
      <View
        style={{
          backgroundColor: "white",
          width: "100%",
          height: "100%",
          flex: 1,
          position: 'absolute'
        }}>
        <View style={{ backgroundColor: "#E3E3E3", height: 250, alignItems: "center", justifyContent: "center" }}>
          <TouchableOpacity><Image style={{
            resizeMode: "contain",
            height: 70,
            width: 70
          }} source={require('./assets/App/DefaultImage.png')} />
            <Text style={{
              position: "absolute", alignSelf: "center", top: 75
            }}>Haz click para agregar imagen</Text>
          </TouchableOpacity>
        </View>
        <TextInput style={{
          top: 270,
          fontWeight: 'bold',
          fontSize: 34,
          height: 80,
          width: 300,
          textAlign: 'center',
          alignSelf: "center",
          position: 'absolute',
          borderWidth: 3,
          paddingHorizontal: 5,
          justifyContent: "flex-start",
          multiline: true,
          borderColor: "#DA4343",
          borderRadius:5
        }}
          placeholder="Titulo"
          placeholderTextColor="#DA4343"
          keyboardType="default"
        />
        <TextInput
          style={{
            top: 370,
            height: 50,
            width: 300,
            alignSelf: "center",
            position: 'absolute',
            borderWidth: 3,
            paddingHorizontal: 5,
            justifyContent: "flex-start",
            multiline: true,
            borderColor: "#DA4343",
            textAlign: "center",
            borderRadius:5
          }}
          placeholder="Descripción"
          placeholderTextColor="#DA4343"
          keyboardType="default"
        />
        <TextInput multiline={true}
          style={{
            top: 440,
            height: 100,
            width: 300,
            alignSelf: "center",
            position: 'absolute',
            borderWidth: 3,
            textAlignVertical: "top",
            paddingHorizontal: 5,
            paddingVertical: 3,
            editable: "true",
            borderColor: "#DA4343",
            borderRadius:5
          }}
          placeholder="Instructivo"
          placeholderTextColor="#DA4343"
          keyboardType="default"
        />
      </View>
      <View style={{
        top: 550,
        flexDirection: "row",
        top: 573,
      }}>
        <TextInput
          style={{
            height: 50,
            top: -15,
            right: -150,
            width: 145,
            alignSelf: "center",
            position: 'absolute',
            borderWidth: 3,
            paddingHorizontal: 5,
            justifyContent: "flex-start",
            multiline: true,
            borderColor: "#DA4343",
            borderRadius:5
          }}
          placeholder="Repeticiones"
          placeholderTextColor="#DA4343"
          keyboardType="number-pad"
        />
        <TextInput
          style={{
            height: 50,
            top: -15,
            right: 5,
            width: 145,
            alignSelf: "center",
            position: 'absolute',
            borderWidth: 3,
            paddingHorizontal: 5,
            justifyContent: "flex-start",
            multiline: true,
            borderColor: "#DA4343",
            borderRadius:5
          }}
          placeholder="Musculos Ejercitados"
          placeholderTextColor="#DA4343"
        />
      </View>
      <TouchableOpacity>
        <View style={{
          position: "absolute",
          top: 625,
          alignSelf: "center",
          backgroundColor: "#43B6DA",
          width: 200,
          height: 55,
          justifyContent: "center",
          borderRadius:5,
          borderWidth:3,
          borderColor:"#24456e"
        }}>
          <Text style={{
            color: "#ffffff",
            textAlign: "center",
            fontSize: 20,
            fontWeight: "bold"
          }}>Subir</Text>
        </View>
      </TouchableOpacity>
      <View style={styles.bottomBar}>
        <TouchableOpacity style={styles.BarradeAbajo} onPress={() => navigation.navigate('Posts')}><Image source={require('./assets/App/IconoHome.png')} style={styles.iconobarra}></Image></TouchableOpacity>
        <TouchableOpacity style={styles.BarradeAbajo}><Image source={require('./assets/App/IconoBuscar.png')} style={styles.iconobarra}></Image></TouchableOpacity>
        <TouchableOpacity style={styles.BarradeAbajo} onPress={() => navigation.navigate('Crear')}><Image source={require('./assets/App/IconoCrear.png')} style={styles.iconobarra}></Image></TouchableOpacity>
        <TouchableOpacity style={styles.BarradeAbajo}><Image source={require('./assets/App/IconoUsuario.png')} style={styles.iconobarra}></Image></TouchableOpacity>
        <TouchableOpacity style={styles.BarradeAbajo}><Image source={require('./assets/App/IconoNotificacion.png')} style={styles.iconobarra}></Image></TouchableOpacity>
      </View>
    </View>
  )
}

////////////////////////////////////////////////////////////////////////

function CrearReceta({ navigation }) {
  return (
    <View style={styles.container}>
      <View
        style={{
          backgroundColor: "white",
          width: "100%",
          height: "100%",
          flex: 1,
          position: 'absolute'
        }}>
        <View style={{ backgroundColor: "#E3E3E3", height: 250, alignItems: "center", justifyContent: "center" }}>
          <TouchableOpacity><Image style={{
            resizeMode: "contain",
            height: 70,
            width: 70
          }} source={require('./assets/App/DefaultImage.png')} />
            <Text style={{
              position: "absolute", alignSelf: "center", top: 75
            }}>Haz click para agregar imagen</Text>
          </TouchableOpacity>
        </View>
        <TextInput style={{
          top: 270,
          fontWeight: 'bold',
          fontSize: 34,
          height: 80,
          width: 300,
          textAlign: 'center',
          alignSelf: "center",
          position: 'absolute',
          borderWidth: 3,
          paddingHorizontal: 5,
          justifyContent: "flex-start",
          multiline: true,
          borderColor: "#DA4343",
          borderRadius:5
        }}
          placeholder="Titulo"
          placeholderTextColor="#DA4343"
          keyboardType="default"
        />
        <TextInput
          style={{
            top: 370,
            height: 50,
            width: 300,
            alignSelf: "center",
            position: 'absolute',
            borderWidth: 3,
            paddingHorizontal: 5,
            justifyContent: "flex-start",
            multiline: true,
            borderColor: "#DA4343",
            textAlign: "center",
            borderRadius:5
          }}
          placeholder="Descripción"
          placeholderTextColor="#DA4343"
          keyboardType="default"
        />
        <TextInput multiline={true}
          style={{
            top: 440,
            height: 100,
            width: 300,
            alignSelf: "center",
            position: 'absolute',
            borderWidth: 3,
            textAlignVertical: "top",
            paddingHorizontal: 5,
            paddingVertical: 3,
            editable: "true",
            borderColor: "#DA4343",
            borderRadius:5
          }}
          placeholder="Instructivo"
          placeholderTextColor="#DA4343"
          keyboardType="default"
        />
      </View>
      <View style={{
        top: 550,
        flexDirection: "row",
        top: 573,
      }}>
        <TextInput
          style={{
            height: 50,
            top: -15,
            right: -150,
            width: 145,
            alignSelf: "center",
            position: 'absolute',
            borderWidth: 3,
            paddingHorizontal: 5,
            justifyContent: "flex-start",
            multiline: true,
            borderColor: "#DA4343",
            borderRadius:5
          }}
          placeholder="Tiempo (hr)"
          placeholderTextColor="#DA4343"
          keyboardType="number-pad"
        />
        <TextInput
          style={{
            height: 50,
            top: -15,
            right: 5,
            width: 145,
            alignSelf: "center",
            position: 'absolute',
            borderWidth: 3,
            paddingHorizontal: 5,
            justifyContent: "flex-start",
            multiline: true,
            borderColor: "#DA4343",
            borderRadius:5
          }}
          placeholder="Dificultad (1-10)"
          placeholderTextColor="#DA4343"
          keyboardType="number-pad"
        />
      </View>
      <TouchableOpacity>
        <View style={{
          position: "absolute",
          top: 625,
          alignSelf: "center",
          backgroundColor: "#43B6DA",
          width: 200,
          height: 55,
          justifyContent: "center",
          borderRadius:5,
          borderWidth:3,
          borderColor:"#24456e"
        }}>
          <Text style={{
            color: "#ffffff",
            textAlign: "center",
            fontSize: 20,
            fontWeight: "bold"
          }}>Subir</Text>
        </View>
      </TouchableOpacity>
      <View style={styles.bottomBar}>
        <TouchableOpacity style={styles.BarradeAbajo} onPress={() => navigation.navigate('Posts')}><Image source={require('./assets/App/IconoHome.png')} style={styles.iconobarra}></Image></TouchableOpacity>
        <TouchableOpacity style={styles.BarradeAbajo}><Image source={require('./assets/App/IconoBuscar.png')} style={styles.iconobarra}></Image></TouchableOpacity>
        <TouchableOpacity style={styles.BarradeAbajo} onPress={() => navigation.navigate('Crear')}><Image source={require('./assets/App/IconoCrear.png')} style={styles.iconobarra}></Image></TouchableOpacity>
        <TouchableOpacity style={styles.BarradeAbajo}><Image source={require('./assets/App/IconoUsuario.png')} style={styles.iconobarra}></Image></TouchableOpacity>
        <TouchableOpacity style={styles.BarradeAbajo}><Image source={require('./assets/App/IconoNotificacion.png')} style={styles.iconobarra}></Image></TouchableOpacity>
      </View>
    </View>
  )
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

const Stack = createNativeStackNavigator();

function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator>
        <Stack.Screen name="Iniciar" component={IniciarScreen} options={{ headerShown: false }} />
        <Stack.Screen name="Posts" component={PostsScreen} options={{ headerShown: false }} />
        <Stack.Screen name="Crear" component={CrearScreen} options={{ headerShown: false }} />
        <Stack.Screen name="CrearReceta" component={CrearReceta} options={{ headerShown: true, headerTitle: "Receta", headerTintColor: "#ffffff", headerStyle: { backgroundColor: '#DA4343' } }} />
        <Stack.Screen name="CrearRutina" component={CrearRutina} options={{ headerShown: true, headerTitle: "Rutina", headerTintColor: "#ffffff", headerStyle: { backgroundColor: '#DA4343' } }} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

const styles = StyleSheet.create({
  titulo: {
    position: 'absolute',
    top: 245,
    alignSelf: "center",
    color: "white",
    fontWeight: "bold",
    fontSize: 40
  },
  container: {
    flex: 1,
    backgroundColor: '#c4c4c4',
    alignItems: 'center',
  },
  barradebusqueda: {
    backgroundColor: '#CFCFCF',
    height: 20,
    width: '100%',
    alignSelf: 'flex-end',
    alignItems: 'center',
  },
  logo: {
    flex: 1,
    width: 220,
    height: 220,
    position: 'absolute',
    top: 30,
    left: 70,
    resizeMode: 'contain'
  },
  iconobarra: {
    alignSelf: 'center',
    height: 35,
    width: 35,
    position: 'relative',
    resizeMode: 'contain'
  },
  button1: {
    alignItems: "center",
    backgroundColor: "#43B6DA",
    position: 'absolute',
    height: 50,
    width: 300,
    top: 750,
    alignSelf: 'center',
    borderRadius: 10,
    borderWidth:3,
    borderColor:"#24456e"
  },
  button2: {
    alignItems: "center",
    backgroundColor: "#43B6DA",
    position: 'absolute',
    height: 50,
    width: 300,
    top: 670,
    alignSelf: 'center',
    borderRadius: 10,
    borderWidth:3,
    borderColor:"#24456e"

  },
  bottomBar: {
    backgroundColor: "#CFCFCF",
    width: "100%",
    height: 65,
    position: 'absolute',
    bottom: 0,
    flexDirection: 'row',
    justifyContent: 'space-evenly',

  },
  BarradeAbajo: {
    bottom: -14
  },
  card: {
    marginLeft: "auto",
    marginRight: "auto",
    borderColor: "#731a1a",
    borderWidth: 5,
    borderRadius: 10,
    backgroundColor: "#DA4343",
    width: "100%",
    height: 500,

  },
  fondo:{
    backgroundColor: "white",
    width: "100%",
    height: "100%",
    flex: 1,
    position: 'absolute'
  },
  receta:{
    color: "#ffffff",
    fontSize: 32,
    fontWeight: "bold",
    textAlign: "center",
    width: 285,
    position: "absolute"
  },
  ImagenPerfil:{
    height: 50,
    width: 50,
    position: "absolute",
    alignSelf: "center",
    top: 5
  },
  Upvote:{
      height: 50,
      width: 50,
      position: "absolute",
      alignSelf: "center",
      top: 60
  },
  textoUpvote:{
    alignSelf: "center",
    top: "28%",
    position: "absolute",
    color: "#ffffff",
    fontSize: 24
  },
  Downvote:{
    height: 50,
    width: 50,
    position: "absolute",
    alignSelf: "center",
    top: 190
  },
  CaldoDePollo: {
    height: 190,
    width: 315,
    top: 50,
    position: "absolute",
    left: 0,
    borderRadius: 5
  },
  OtrosDatos:{
    alignSelf: "center",
    top: "50%",
    position: "absolute",
    color: "#ffffff",
    fontSize: 24
  },
  TextoDownvotes:{
    alignSelf: "left",
    top: "60%",
    position: "absolute",
    color: "#ffffff",
    fontSize: 24
  },
  textoDescripcion:{

    alignSelf: "left",
    top: "70%",
    position: "absolute",
    color: "#ffffff",
    fontSize: 24
  },

  textoVisitas:{

    alignSelf: "left",
    top: "87%",
    position: "absolute",
    color: "#ffffff",
    fontSize: 24
  },
  barritadeabajo:{
      height: 65,
      position: "relative",
      top: "164%",
      backgroundColor: "#ff0000"
    
  },
  cardAAA:{width: "93%",
  alignSelf: "center"},
  estonosequees:{
    backgroundColor: "#ffffff",
    width: "100%",
    height: 25
  },
  estotampocosequees:{
    backgroundColor: "#b42222",
    width: 60,
    alignSelf: "flex-end",
    height: "100%"
  }
});
export default App;